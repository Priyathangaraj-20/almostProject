package exam.model;

public class questionModel {
		int q_id;
		int class_no;
		String que;
		String op1;
		String op2;
		String op3;
		String op4;
		String ans;
		String sub_name;
		public questionModel(int q_id, int class_no, String que, String op1, String op2, String op3, String op4,
				String ans, String sub_name) {
			super();
			this.q_id = q_id;
			this.class_no = class_no;
			this.que = que;
			this.op1 = op1;
			this.op2 = op2;
			this.op3 = op3;
			this.op4 = op4;
			this.ans = ans;
			this.sub_name = sub_name;
		}
		public questionModel(String Sub_name) {
			this.sub_name=Sub_name;
		}
		public questionModel(int qid) {
			this.q_id=qid;
		}
		public int getQ_id() {
			return q_id;
		}
		public void setQ_id(int q_id) {
			this.q_id = q_id;
		}
		public int getClass_no() {
			return class_no;
		}
		public void setClass_no(int class_no) {
			this.class_no = class_no;
		}
		public String getQue() {
			return que;
		}
		public void setQue(String que) {
			this.que = que;
		}
		public String getOp1() {
			return op1;
		}
		public void setOp1(String op1) {
			this.op1 = op1;
		}
		public String getOp2() {
			return op2;
		}
		public void setOp2(String op2) {
			this.op2 = op2;
		}
		public String getOp3() {
			return op3;
		}
		public void setOp3(String op3) {
			this.op3 = op3;
		}
		public String getOp4() {
			return op4;
		}
		public void setOp4(String op4) {
			this.op4 = op4;
		}
		public String getAns() {
			return ans;
		}
		public void setAns(String ans) {
			this.ans = ans;
		}
		public String getSub_name() {
			return sub_name;
		}
		public void setSub_name(String sub_name) {
			this.sub_name = sub_name;
		}

}
