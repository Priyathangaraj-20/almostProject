package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/homeadmin")
public class homeadmin extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		PrintWriter out= response.getWriter();
		String option=request.getParameter("op");
		String quest=request.getParameter("question");
		String stud=request.getParameter("student");
		String exam=request.getParameter("exam");
		HttpSession adminsess1=request.getSession();
		adminsess1.setAttribute("clss_no", option);
	
			
			if(quest!=null){
				rd=request.getRequestDispatcher("questionsAdmin");
				rd.forward(request, response);
			}else if(stud!=null){
				rd=request.getRequestDispatcher("studentAdmin.jsp");
				rd.forward(request, response);
			}else if(exam!=null){
				System.out.println("helllllooooo");
				rd=request.getRequestDispatcher("examList");
				rd.forward(request, response);
			
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
