package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import exam.model.*;

import exam.DAO.selectQuestions;

@WebServlet("/EditQuestion")
public class EditQuestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		
		ArrayList<questionModel> editquest= new ArrayList<questionModel>();
		String oper="";
		int q_id=0;
		if(request.getParameter("oper")!=null )
		{
			oper=request.getParameter("oper");
			q_id=Integer.valueOf((String)request.getParameter("q_id"));
			System.out.println(q_id);
			if(oper.equals("modify"))
			{
				editquest = selectQuestions.getQuestById(q_id);
				request.setAttribute("editquest", editquest);
				System.out.println(editquest);
				rd=request.getRequestDispatcher("editQuestAdmin.jsp");		    
		 	    rd.forward(request, response);
			}
			else if(oper.equals("delete"))
			{
				if(selectQuestions.deleteQuestById(q_id)==true)
				{
					rd=request.getRequestDispatcher("questionsAdmin");		    
			 	    rd.forward(request, response);
				}
			}
			
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
