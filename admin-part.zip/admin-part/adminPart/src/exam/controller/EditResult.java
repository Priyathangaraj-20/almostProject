package exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectResultStudentDAO;
import exam.DAO.selectStudents;
import exam.model.studentResultModel;

@WebServlet("/EditResult")
public class EditResult extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		ArrayList<studentResultModel> editstud= new ArrayList<studentResultModel>();
		String oper="";
		
		HttpSession adminsess1= request.getSession();
		HttpSession adminsess2= request.getSession();

		String sub_name= (String) adminsess2.getAttribute("sub_name");
		String email_id=(String) request.getParameter("email_id");
		int clss_no=Integer.valueOf((String) adminsess1.getAttribute("clss_no"));
		String totalmarks= Integer.toString(selectResultStudentDAO.getMarks(clss_no, sub_name));
		adminsess2.removeAttribute("email_id");
		System.out.print(sub_name);
		if(request.getParameter("oper")!=null )
		{
			oper=request.getParameter("oper");
			
			adminsess1.setAttribute("email_id", email_id);
			if(oper.equals("modify"))
			{
				if( selectResultStudentDAO.getResultsById(clss_no, sub_name, email_id)!=null){
				editstud = selectResultStudentDAO.getResultsById(clss_no, sub_name, email_id);
				request.setAttribute("resByIdlist", editstud);
				for(studentResultModel r:editstud)
				{
					System.out.print(r.getApp_date()+","+r.getApp_id()+","+r.getEmail_id());
				}
				request.setAttribute("totalmarks", totalmarks);
				rd=request.getRequestDispatcher("EditResultAdmin.jsp");		    
		 	    rd.forward(request, response);
		 	    }else
		 	    {
		 	    	System.out.print("failed");
		 	    }
			}
			else if(oper.equals("delete"))
			{
				if(selectResultStudentDAO.deleteres(email_id, sub_name)==true)
				{
					System.out.print("finally");
					rd=request.getRequestDispatcher("ResultStudent11");		    
			 	    rd.forward(request, response);
				}
			}
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
