package exam.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.selectExam;
import exam.DAO.selectResultStudentDAO;
import exam.model.appearexamModel;
import exam.model.examModel;

@WebServlet("/editResultsPage")
public class editResultsPage extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		Boolean flag=false;
		Boolean flag1=false;
		PrintWriter out=response.getWriter();
		HttpSession adminsess1= request.getSession();
		String email_id1= (String) adminsess1.getAttribute("email_id");
		int app_id=Integer.valueOf((String)request.getParameter("appid"));
		int obt_marks=Integer.valueOf((String)request.getParameter("obtmarks"));
		int exam_id=Integer.valueOf((String) request.getParameter("examid"));
		String app_date=request.getParameter("appdate");
		String email_id=request.getParameter("email_id");
		String remarks=request.getParameter("remarks");
		String status=request.getParameter("status");
		String sub_name=request.getParameter("subname");
		
		appearexamModel m= new appearexamModel(app_id, obt_marks, exam_id, app_date, email_id1, remarks, status, sub_name);
		if(selectResultStudentDAO.updateResult(m, email_id1)==true)
		{
			rd=request.getRequestDispatcher("ResultStudent11");
			rd.forward(request, response);
		}else{
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Couldn't update!! Please Check the Credentials');");
			out.println("location='EditResult';");
			out.println("</script>");
		}
	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
