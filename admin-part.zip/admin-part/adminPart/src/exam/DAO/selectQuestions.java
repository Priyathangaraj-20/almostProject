package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exam.model.examModel;
import exam.model.questionModel;

public class selectQuestions {
	 private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<questionModel> getQuestionForStud(String sub_name, int clss_no)
	  {
		  ArrayList <questionModel> quelist=new ArrayList<questionModel>();
		  questionModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select q_id, clss_no, que, op1, op2, op3, op4, ans, sub_name from question where sub_name=? and clss_no=? "); 
	      stmt.setString(1, sub_name);
	      stmt.setInt(2, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new questionModel(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));	
			  quelist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return quelist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<questionModel> getSubjectName(int clss_no)
	  {
		  ArrayList <questionModel> quelist=new ArrayList<questionModel>();
		  questionModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("SELECT distinct sub_name FROM question WHERE clss_no=?"); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		  while(rs.next())
			  {  		   
			  temp=new questionModel(rs.getString(1) );	
			  quelist.add(temp); 
			  System.out.print(temp);
			  }  
		     closeConnection();	 
		     return quelist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }  	  
	  }
	  
	  public static ArrayList<questionModel> getQuestById(int q_id)
	  {
		  ArrayList <questionModel> quelist=new ArrayList<questionModel>();
		  questionModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select q_id, clss_no, que, op1, op2, op3, op4, ans, sub_name from question where q_id=? "); 
	      stmt.setInt(1, q_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new questionModel(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));	
			  quelist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return quelist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }
	  }
	  public static ArrayList<questionModel> getQuestId()
	  {
		  ArrayList <questionModel> quelist=new ArrayList<questionModel>();
		  questionModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select q_id from question "); 
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new questionModel(rs.getInt(1));	
			  quelist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return quelist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }
	  }
	  
	  public static Boolean updateQuestById(questionModel q, int q_id)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("update question set q_id=?, clss_no=?, que=?, op1=?, op2=?, op3=?, op4=?, ans=?, sub_name=? where q_id=? "); 
	      stmt.setInt(1, q.getQ_id());
	      stmt.setInt(2, q.getClass_no());
	      stmt.setString(3, q.getQue());
	      stmt.setString(4, q.getOp1());
	      stmt.setString(5, q.getOp2());
	      stmt.setString(6, q.getOp3());
	      stmt.setString(7, q.getOp4());
	      stmt.setString(8, q.getAns());
	      stmt.setString(9, q.getSub_name());
	      stmt.setInt(10, q_id);
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
	  
	  public static Boolean addQuest(questionModel q)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("insert into question values (?,?,?,?,?,?,?,?,?) "); 
	      stmt.setInt(1, q.getQ_id());
	      stmt.setInt(9, q.getClass_no());
	      stmt.setString(2, q.getQue());
	      stmt.setString(3, q.getOp1());
	      stmt.setString(4, q.getOp2());
	      stmt.setString(5, q.getOp3());
	      stmt.setString(6, q.getOp4());
	      stmt.setString(7, q.getAns());
	      stmt.setString(8, q.getSub_name());
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
	  
	  public static Boolean deleteQuestById( int q_id)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("delete from question where q_id=? "); 
	      stmt.setInt(1, q_id);
	     
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
}
