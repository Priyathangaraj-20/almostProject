package exam.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import exam.model.registrationmodel;
import exam.model.studentResultModel;
import exam.model.appearexamModel;
import exam.model.examModel;

public class selectResultStudentDAO {
	 private static Connection con; 
	  private static PreparedStatement stmt;
	  
	public static void getConnection()
	  {	 	     
	      try 
	      {
	    	 Class.forName("com.mysql.jdbc.Driver");   // Driver should be registered
	    	  con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/examdb","root","");  
	    
	         
	      } 
	      catch (Exception e) 
	      {
	         e.printStackTrace();
	      }
		   
		 
	  }
	  public static void closeConnection()
	  {
		  try{
			  if(con.isClosed()==false)
		          con.close();   // closing the connection
		  }
		  catch(Exception e)
		  { e.printStackTrace();	 }
	  }  
	  
	 
	  public static ArrayList<studentResultModel> getResults(int clss_no, String sub_name)
	  {
		  ArrayList <studentResultModel> studlist=new ArrayList<studentResultModel>();
		  studentResultModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("SELECT clss_no,  appear_exam.email_id, name,app_date, app_id, obt_marks, status, remarks, sub_name,exam_id from appear_exam, registration where appear_exam.email_id=registration.email_id AND appear_exam.sub_name=? AND registration.clss_no=?"); 
	      stmt.setInt(2, clss_no);
	      stmt.setString(1, sub_name);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new studentResultModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getInt(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getInt(10));	
			  studlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return studlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }
	  }
	 
	  public static ArrayList<studentResultModel> getResultsById(int clss_no, String sub_name, String email_id)
	  {
		  ArrayList <studentResultModel> studlist=new ArrayList<studentResultModel>();
		  studentResultModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("SELECT clss_no, appear_exam.email_id, name,app_date, app_id, obt_marks, status, remarks, sub_name, exam_id from appear_exam, registration where appear_exam.email_id=registration.email_id AND sub_name=? AND clss_no=? AND appear_exam.email_id=?"); 
	      stmt.setInt(2, clss_no);
	      stmt.setString(1, sub_name);
	      stmt.setString(3, email_id);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new studentResultModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getInt(5),rs.getInt(6), rs.getString(7), rs.getString(8), rs.getString(9),rs.getInt(10));	
			  studlist.add(temp);
			  for(studentResultModel r:studlist)
				{
					System.out.print(r.getApp_date()+","+r.getApp_id()+","+r.getEmail_id());
				}
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return studlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  
		  {	  e.printStackTrace();	 return null; }
	  }
	  
	  
	  public static Boolean deleteres(String email_id, String sub_name)
	  {
		  int nor=0;
		  try{
			  getConnection();
		      stmt=con.prepareStatement("DELETE FROM `appear_exam` WHERE sub_name=? AND email_id=?"); 
		      stmt.setString(2, email_id);
		      stmt.setString(1, sub_name);
			   nor=stmt.executeUpdate();
			   System.out.println("deleted");
			     closeConnection();
			     if(nor>0){
			    	 System.out.println("deleted11");
			     return true;
			     }
			     return false;
			     
		  }catch (SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
	  
	  
	  public static int getMarks(int clss_no, String sub_name)
	  {
		 
		 int n=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("select total_marks from exam where clss_no=? and sub_name=? "); 
	      stmt.setInt(1, clss_no);
	      stmt.setString(2, sub_name);
		  ResultSet rs=stmt.executeQuery();  

		  while(rs.next())
			  {  		   
			 n=rs.getInt(1);
			  }  
		     closeConnection();	 
		     return n;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return 0; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return 0; }
	  }
	  
	  public static ArrayList<studentResultModel> getSub(int clss_no)
	  {
		  ArrayList <studentResultModel> studlist=new ArrayList<studentResultModel>();
		  studentResultModel temp; 
		  	  
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("SELECT DISTINCT sub_name from appear_exam, registration where appear_exam.email_id=registration.email_id and clss_no=?"); 
	      stmt.setInt(1, clss_no);
		  ResultSet rs=stmt.executeQuery();  
		 // System.out.println(branch);
		  while(rs.next())
			  {  		   
			  temp=new studentResultModel(rs.getString(1));	
			  studlist.add(temp); 
			  System.out.println(temp);
			  }  
		     closeConnection();	 
		     return studlist;
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return null; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return null; }
	  }
	  

	  
	  public static Boolean updateResult(appearexamModel r, String email_id)
	  {
		  int nor=0;
		  try
		  {
		  getConnection();
	      stmt=con.prepareStatement("update appear_exam set app_id=?, obt_marks=?,exam_id=?,app_date=?, email_id=?, remarks=?, status=?, sub_name=? where email_id=?"); 
	      stmt.setInt(1, r.getApp_id());
	      stmt.setInt(2, r.getObt_marks());
	      stmt.setInt(3, r.getExam_id());
	      stmt.setString(4, r.getApp_date());
	      stmt.setString(5, r.getEmail_id());
	      stmt.setString(6, r.getRemarks());
	      stmt.setString(7, r.getStatus());
	      stmt.setString(8, r.getSub_name());
	      stmt.setString(9, email_id);
	      System.out.println(email_id);
		   nor=stmt.executeUpdate();
		     closeConnection();
		     if(nor>0){
		     return true;
		     }
		     return false;
		     
		  }
		  catch(SQLException e)
		  {	  e.printStackTrace();	 return false; }
		  catch(Exception e)
		  {	  e.printStackTrace();	 return false; }
	  }
	  
	  
}
