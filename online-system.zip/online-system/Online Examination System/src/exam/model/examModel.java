package exam.model;

public class examModel {
		int exam_id;
		String sub_name;
		int clss_no;
		String start_date;
		String end_date;
		String exam_date;
		int no_of_que;
		String time_interval;
		int total_marks;
		
		public examModel(int exam_id, String sub_name, int clss_no, int no_of_que, String time_interval, int total_marks, String start_date, String end_date,
				String exam_date) {
			super();
			this.exam_id = exam_id;
			this.sub_name = sub_name;
			this.clss_no = clss_no;
			this.start_date = start_date;
			this.end_date = end_date;
			this.exam_date = exam_date;
			this.no_of_que = no_of_que;
			this.time_interval = time_interval;
			this.total_marks = total_marks;
		}
		
		public String getExam_date() {
			return exam_date;
		}


		public void setExam_date(String exam_date) {
			this.exam_date = exam_date;
		}
		public examModel(String sub_name, int clss_no) {
			this.sub_name = sub_name;
			this.clss_no = clss_no;
		}
		public int getExam_id() {
			return exam_id;
		}
		public void setExam_id(int exam_id) {
			this.exam_id = exam_id;
		}
		public String getSub_name() {
			return sub_name;
		}
		public void setSub_name(String sub_name) {
			this.sub_name = sub_name;
		}
		public int getClss_no() {
			return clss_no;
		}
		public void setClss_no(int clss_no) {
			this.clss_no = clss_no;
		}
		public String getStart_date() {
			return start_date;
		}
		public void setStart_date(String start_date) {
			this.start_date = start_date;
		}
		public String getEnd_date() {
			return end_date;
		}
		public void setEnd_date(String end_date) {
			this.end_date = end_date;
		}
		public int getNo_of_que() {
			return no_of_que;
		}
		public void setNo_of_que(int no_of_que) {
			this.no_of_que = no_of_que;
		}
		public String getTime_interval() {
			return time_interval;
		}
		public void setTime_interval(String time_interval) {
			this.time_interval = time_interval;
		}
		public int getTotal_marks() {
			return total_marks;
		}
		public void setTotal_marks(int total_marks) {
			this.total_marks = total_marks;
		}
}
