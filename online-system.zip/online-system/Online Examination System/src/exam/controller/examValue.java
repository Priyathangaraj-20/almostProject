package exam.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import exam.DAO.examValueDAO;
import exam.DAO.mainExamDAO;
import exam.model.appearexamModel;
import exam.model.questionModel;

@WebServlet("/examValue")
public class examValue extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher rd;
		int n1=0;
		int correctans=0;
		String ans=null;
		HttpSession session3=request.getSession();
		HttpSession session1=request.getSession();
		ArrayList<questionModel> question;
		String sub_name=(String) session3.getAttribute("sub_name");
		int clss_no=(int) session3.getAttribute("clss_no");
		String email_id=(String) session1.getAttribute("email_id");
		int exam_id=(int) session3.getAttribute("exam_id");
		if(mainExamDAO.getQuestionForStud(sub_name, clss_no)!=null)
		{
			question=mainExamDAO.getQuestionForStud(sub_name, clss_no);
			
			int n=mainExamDAO.getQuestionCount(clss_no, sub_name);
			while(n1<=n){
				ans=request.getParameter("option"+n1);
				if(ans!=null){
			for(questionModel r: question)
			{
				if(ans.equals(r.getAns()))
						{
					 System.out.println(r.getQ_id());
					  correctans++;
						}
			}
				}
				n1++;
			}
			String status=null;
			String remarks=null;
			if(correctans==(n1))
			{
				status="pass";
				remarks="excellent";
			}else if(correctans >= (n1/2))
			{
				status="pass";
				remarks="good";
			}else
			{
				status="fail";
				remarks="work hard";
			}
			
			String pattern ="yyyy-MM-dd";
			SimpleDateFormat simpleDate=new SimpleDateFormat(pattern);
			String date=simpleDate.format(new Date());
			int id1 = examValueDAO.getid();
			int id=id1+1;
			appearexamModel a=new appearexamModel(id, correctans, exam_id, date, email_id, remarks, status, sub_name);
			if(examValueDAO.updateappearExam(a)== true)
			{
				a.setApp_id(id++);
				rd= request.getRequestDispatcher("examOver.jsp");
				rd.forward(request, response);
				
			}
		}
	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
